# Lab 9 - Page Object Model + Data-Driven Testing

Du an nay trien khai day du cac yeu cau trong de Lab 9:
- BasePage + BaseTest
- Page Object cho SauceDemo
- Data-driven testing voi Excel
- Data-driven testing voi JSON
- Java Faker cho form checkout
- ConfigReader da moi truong
- RetryAnalyzer + FlakySimulationTest
- Cau truc framework POM + DDT hoan chinh

## Cau truc chinh

```text
src/
|-- main/java/framework/
|   |-- base/
|   |   |-- BasePage.java
|   |   |-- BaseTest.java
|   |   `-- DriverFactory.java
|   |-- config/
|   |   `-- ConfigReader.java
|   |-- model/
|   |   |-- CheckoutData.java
|   |   `-- UserData.java
|   |-- pages/
|   |   |-- CartPage.java
|   |   |-- CheckoutCompletePage.java
|   |   |-- CheckoutOverviewPage.java
|   |   |-- CheckoutPage.java
|   |   |-- InventoryPage.java
|   |   `-- LoginPage.java
|   `-- utils/
|       |-- ExcelReader.java
|       |-- JsonReader.java
|       |-- RetryAnalyzer.java
|       |-- RetryListener.java
|       |-- ScreenshotUtil.java
|       `-- TestDataFactory.java
`-- test/
    |-- java/tests/
    |   |-- CartTest.java
    |   |-- CheckoutFakerTest.java
    |   |-- ExcelLoginTest.java
    |   |-- FlakySimulationTest.java
    |   |-- LoginTest.java
    |   `-- UserLoginTest.java
    `-- resources/
        |-- config-dev.properties
        |-- config-staging.properties
        |-- testdata/
        |   |-- login_data.xlsx
        |   `-- users.json
        |-- testng-regression.xml
        `-- testng-smoke.xml
```

## Lenh chay nhanh

```bash
mvn test
mvn test -DsuiteXmlFile=src/test/resources/testng-smoke.xml
mvn test -Denv=staging
mvn test -Denv=dev -Dbrowser=chrome -Dheadless=true
```

## Ghi chu
- Suite smoke chi chay group `smoke`, tuong ung sheet `SmokeCases`.
- Suite regression chay group `smoke` va `regression`, bao gom ca 3 sheet Excel, JSON, Faker va flaky simulation.
- Retry mac dinh duoc doc tu file config. Dat `retry.count=0` trong file config neu muon tat co che retry.
