package tests;

import framework.base.BaseTest;
import framework.pages.InventoryPage;
import framework.pages.LoginPage;
import framework.utils.ExcelReader;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class ExcelLoginTest extends BaseTest {

    private static final String EXCEL_RESOURCE = "testdata/login_data.xlsx";

    @DataProvider(name = "smokeCases", parallel = true)
    public Object[][] smokeCases() {
        return ExcelReader.getData(EXCEL_RESOURCE, "SmokeCases");
    }

    @DataProvider(name = "negativeCases", parallel = true)
    public Object[][] negativeCases() {
        return ExcelReader.getData(EXCEL_RESOURCE, "NegativeCases");
    }

    @DataProvider(name = "boundaryCases", parallel = true)
    public Object[][] boundaryCases() {
        return ExcelReader.getData(EXCEL_RESOURCE, "BoundaryCases");
    }

    @Test(groups = {"smoke", "regression"}, dataProvider = "smokeCases")
    public void smokeLoginFromExcel(
            String username,
            String password,
            String expectedUrl,
            String description) {

        setTestName(description);

        InventoryPage inventoryPage = new LoginPage(getDriver()).login(username, password);

        Assert.assertTrue(
                inventoryPage.isLoaded(),
                "Dang nhap smoke phai thanh cong.");
        Assert.assertTrue(
                getDriver().getCurrentUrl().contains(expectedUrl),
                "URL hien tai phai chua: " + expectedUrl);
    }

    @Test(groups = {"regression"}, dataProvider = "negativeCases")
    public void negativeLoginFromExcel(
            String username,
            String password,
            String expectedError,
            String description) {

        setTestName(description);

        LoginPage loginPage = new LoginPage(getDriver())
                .loginExpectingFailure(username, password);

        Assert.assertTrue(loginPage.isErrorDisplayed(), "Thong bao loi phai hien thi.");
        Assert.assertEquals(
                loginPage.getErrorMessage(),
                expectedError,
                "Thong diep loi thuc te phai trung voi du lieu trong Excel.");
    }

    @Test(groups = {"regression"}, dataProvider = "boundaryCases")
    public void boundaryLoginFromExcel(
            String username,
            String password,
            String expectedError,
            String description) {

        setTestName(description);

        LoginPage loginPage = new LoginPage(getDriver())
                .loginExpectingFailure(username, password);

        Assert.assertTrue(loginPage.isErrorDisplayed(), "Thong bao loi phai hien thi.");
        Assert.assertEquals(
                loginPage.getErrorMessage(),
                expectedError,
                "Thong diep loi thuc te phai trung voi du lieu boundary.");
    }
}
