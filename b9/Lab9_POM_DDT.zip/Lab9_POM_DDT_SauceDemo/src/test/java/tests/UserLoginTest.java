package tests;

import framework.base.BaseTest;
import framework.model.UserData;
import framework.pages.LoginPage;
import framework.utils.JsonReader;
import java.util.ArrayList;
import java.util.List;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class UserLoginTest extends BaseTest {

    private static final String JSON_RESOURCE = "testdata/users.json";

    @DataProvider(name = "jsonUsers", parallel = true)
    public Object[][] jsonUsers() {
        List<UserData> users = JsonReader.readUsers(JSON_RESOURCE);
        List<Object[]> rows = new ArrayList<>();

        for (UserData user : users) {
            rows.add(new Object[]{user});
        }

        return rows.toArray(new Object[0][]);
    }

    @Test(groups = {"regression"}, dataProvider = "jsonUsers")
    public void loginWithJsonData(UserData userData) {
        setTestName(userData.getDescription());

        LoginPage loginPage = new LoginPage(getDriver());

        if (userData.isExpectSuccess()) {
            Assert.assertTrue(
                    loginPage.login(userData.getUsername(), userData.getPassword()).isLoaded(),
                    "Case success tu JSON phai dang nhap thanh cong.");
        } else {
            LoginPage failedPage = loginPage
                    .loginExpectingFailure(userData.getUsername(), userData.getPassword());

            Assert.assertTrue(
                    failedPage.isErrorDisplayed(),
                    "Case failure tu JSON phai hien thi thong bao loi.");
        }
    }
}
