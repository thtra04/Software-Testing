package tests;

import framework.base.BaseTest;
import framework.model.CheckoutData;
import framework.pages.CheckoutCompletePage;
import framework.pages.LoginPage;
import framework.utils.TestDataFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

public class CheckoutFakerTest extends BaseTest {

    @Test(groups = {"regression"}, description = "Dung Java Faker tao du lieu ngau nhien cho checkout")
    public void shouldCheckoutWithRandomData() {
        CheckoutData checkoutData = TestDataFactory.randomCheckoutData();
        setTestName("Faker checkout - "
                + checkoutData.getFirstName() + " "
                + checkoutData.getLastName());

        System.out.println("[Faker] " + checkoutData);

        CheckoutCompletePage completePage = new LoginPage(getDriver())
                .login("standard_user", "secret_sauce")
                .addFirstItemToCart()
                .goToCart()
                .goToCheckout()
                .fillCheckoutForm(checkoutData)
                .finishOrder();

        Assert.assertTrue(
                completePage.isLoaded(),
                "Order phai di den trang hoan tat sau khi submit du lieu Faker.");
        Assert.assertTrue(
                completePage.getCompleteHeader().toLowerCase().contains("thank"),
                "Trang complete phai hien thi thong diep thanh cong.");
    }
}
