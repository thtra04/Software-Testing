package tests;

import framework.base.BaseTest;
import framework.pages.InventoryPage;
import framework.pages.LoginPage;
import org.testng.Assert;
import org.testng.annotations.Test;

public class LoginTest extends BaseTest {

    @Test(groups = {"regression"}, description = "Dang nhap thanh cong voi standard_user")
    public void shouldLoginSuccessfullyWithStandardUser() {
        InventoryPage inventoryPage =
                new LoginPage(getDriver()).login("standard_user", "secret_sauce");

        Assert.assertTrue(
                inventoryPage.isLoaded(),
                "Trang inventory phai hien thi sau khi dang nhap thanh cong.");
    }

    @Test(groups = {"regression"}, description = "Dang nhap thanh cong voi problem_user")
    public void shouldLoginSuccessfullyWithProblemUser() {
        InventoryPage inventoryPage =
                new LoginPage(getDriver()).login("problem_user", "secret_sauce");

        Assert.assertTrue(
                inventoryPage.isLoaded(),
                "problem_user van phai vao duoc trang inventory.");
    }

    @Test(groups = {"regression"}, description = "Khong cho locked_out_user dang nhap")
    public void shouldShowErrorForLockedOutUser() {
        LoginPage loginPage =
                new LoginPage(getDriver()).loginExpectingFailure("locked_out_user", "secret_sauce");

        Assert.assertTrue(loginPage.isErrorDisplayed(), "Thong bao loi phai duoc hien thi.");
        Assert.assertTrue(
                loginPage.getErrorMessage().contains("locked out"),
                "Noi dung loi phai cho biet tai khoan bi khoa.");
    }

    @Test(groups = {"regression"}, description = "Bao loi khi bo trong password")
    public void shouldShowErrorWhenPasswordIsEmpty() {
        LoginPage loginPage =
                new LoginPage(getDriver()).loginExpectingFailure("standard_user", "");

        Assert.assertTrue(loginPage.isErrorDisplayed(), "Thong bao loi phai duoc hien thi.");
        Assert.assertEquals(
                loginPage.getErrorMessage(),
                "Epic sadface: Password is required",
                "Thong diep loi phai dung voi truong hop bo trong password.");
    }
}
