package tests;

import framework.base.BaseTest;
import framework.pages.CartPage;
import framework.pages.LoginPage;
import org.testng.Assert;
import org.testng.annotations.Test;

public class CartTest extends BaseTest {

    @Test(groups = {"regression"}, description = "Fluent interface addFirstItemToCart -> goToCart")
    public void shouldAddFirstItemToCartUsingFluentInterface() {
        CartPage cartPage = new LoginPage(getDriver())
                .login("standard_user", "secret_sauce")
                .addFirstItemToCart()
                .goToCart();

        Assert.assertEquals(
                cartPage.getItemCount(),
                1,
                "Gio hang phai co 1 san pham sau khi them item dau tien.");
    }

    @Test(groups = {"regression"}, description = "Them san pham theo ten va kiem tra trong gio")
    public void shouldAddSpecificProductByName() {
        CartPage cartPage = new LoginPage(getDriver())
                .login("standard_user", "secret_sauce")
                .addItemByName("Sauce Labs Backpack")
                .goToCart();

        Assert.assertTrue(
                cartPage.getItemNames().contains("Sauce Labs Backpack"),
                "Danh sach item trong gio phai chua Sauce Labs Backpack.");
    }

    @Test(groups = {"regression"}, description = "Xoa san pham dau tien khoi gio")
    public void shouldRemoveFirstItemFromCart() {
        CartPage cartPage = new LoginPage(getDriver())
                .login("standard_user", "secret_sauce")
                .addFirstItemToCart()
                .goToCart();

        cartPage.removeFirstItem();

        Assert.assertEquals(
                cartPage.getItemCount(),
                0,
                "Gio hang phai rong sau khi xoa item duy nhat.");
    }

    @Test(groups = {"regression"}, description = "CartPage khong co item tra ve 0")
    public void shouldReturnZeroForEmptyCart() {
        CartPage cartPage = new LoginPage(getDriver())
                .login("standard_user", "secret_sauce")
                .goToCart();

        Assert.assertEquals(
                cartPage.getItemCount(),
                0,
                "Khi gio hang khong co item, getItemCount() phai tra ve 0.");
    }
}
