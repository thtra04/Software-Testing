package framework.pages;

import framework.base.BasePage;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * Page Object cho trang danh sach san pham.
 */
public class InventoryPage extends BasePage {

    @FindBy(className = "inventory_list")
    private WebElement inventoryList;

    @FindBy(className = "shopping_cart_badge")
    private WebElement cartBadge;

    @FindBy(className = "shopping_cart_link")
    private WebElement cartLink;

    @FindBy(css = ".inventory_item")
    private List<WebElement> inventoryItems;

    @FindBy(css = ".inventory_item button")
    private List<WebElement> addToCartButtons;

    public InventoryPage(WebDriver driver) {
        super(driver);
    }

    public boolean isLoaded() {
        return isElementVisible(By.className("inventory_list"));
    }

    public InventoryPage addFirstItemToCart() {
        if (!addToCartButtons.isEmpty()) {
            waitAndClick(addToCartButtons.get(0));
        }
        return this;
    }

    public InventoryPage addItemByName(String name) {
        for (WebElement item : inventoryItems) {
            String itemName = item.findElement(By.className("inventory_item_name"))
                    .getText()
                    .trim();
            if (itemName.equalsIgnoreCase(name)) {
                WebElement addButton = item.findElement(By.tagName("button"));
                waitAndClick(addButton);
                return this;
            }
        }
        throw new IllegalArgumentException("Khong tim thay san pham: " + name);
    }

    public int getCartItemCount() {
        if (!isElementVisible(By.className("shopping_cart_badge"))) {
            return 0;
        }

        try {
            return Integer.parseInt(getText(cartBadge));
        } catch (Exception exception) {
            return 0;
        }
    }

    public CartPage goToCart() {
        waitAndClick(cartLink);
        waitForPageLoad();
        return new CartPage(driver);
    }
}
