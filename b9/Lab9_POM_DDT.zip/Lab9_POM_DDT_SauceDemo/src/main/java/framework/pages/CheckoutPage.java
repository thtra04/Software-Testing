package framework.pages;

import framework.base.BasePage;
import framework.model.CheckoutData;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * Page Object cho buoc nhap thong tin checkout.
 */
public class CheckoutPage extends BasePage {

    @FindBy(id = "first-name")
    private WebElement firstNameField;

    @FindBy(id = "last-name")
    private WebElement lastNameField;

    @FindBy(id = "postal-code")
    private WebElement postalCodeField;

    @FindBy(id = "continue")
    private WebElement continueButton;

    public CheckoutPage(WebDriver driver) {
        super(driver);
    }

    public boolean isLoaded() {
        return isElementVisible(By.id("continue"));
    }

    public CheckoutOverviewPage fillCheckoutForm(String firstName, String lastName, String postalCode) {
        waitAndType(firstNameField, firstName);
        waitAndType(lastNameField, lastName);
        waitAndType(postalCodeField, postalCode);
        waitAndClick(continueButton);
        waitForPageLoad();
        return new CheckoutOverviewPage(driver);
    }

    public CheckoutOverviewPage fillCheckoutForm(CheckoutData checkoutData) {
        return fillCheckoutForm(
                checkoutData.getFirstName(),
                checkoutData.getLastName(),
                checkoutData.getPostalCode());
    }
}
