package framework.pages;

import framework.base.BasePage;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * Page Object cho buoc xac nhan checkout.
 */
public class CheckoutOverviewPage extends BasePage {

    @FindBy(id = "finish")
    private WebElement finishButton;

    @FindBy(css = ".cart_item")
    private List<WebElement> overviewItems;

    public CheckoutOverviewPage(WebDriver driver) {
        super(driver);
    }

    public boolean isLoaded() {
        return isElementVisible(By.id("finish"));
    }

    public int getOverviewItemCount() {
        return overviewItems == null ? 0 : overviewItems.size();
    }

    public CheckoutCompletePage finishOrder() {
        waitAndClick(finishButton);
        waitForPageLoad();
        return new CheckoutCompletePage(driver);
    }
}
