package framework.base;

import framework.config.ConfigReader;
import framework.utils.ScreenshotUtil;
import java.time.Duration;
import org.openqa.selenium.WebDriver;
import org.testng.ITest;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

/**
 * Quan ly vong doi WebDriver cho moi test method bang ThreadLocal.
 */
public abstract class BaseTest implements ITest {

    private static final ThreadLocal<WebDriver> TL_DRIVER = new ThreadLocal<>();
    private final ThreadLocal<String> testName = new ThreadLocal<>();

    protected WebDriver getDriver() {
        return TL_DRIVER.get();
    }

    protected void setTestName(String customTestName) {
        testName.set(customTestName);
    }

    protected String getDisplayName(ITestResult result) {
        String currentName = testName.get();
        if (currentName != null && !currentName.isBlank()) {
            return currentName;
        }
        return result.getMethod().getMethodName();
    }

    @Override
    public String getTestName() {
        return testName.get();
    }

    @Parameters({"browser", "env"})
    @BeforeMethod(alwaysRun = true)
    public void setUp(@Optional("chrome") String browser, @Optional("dev") String env) {
        System.setProperty("env", env);
        ConfigReader configReader = ConfigReader.getInstance();

        String resolvedBrowser = (browser == null || browser.isBlank())
                ? configReader.getBrowser()
                : browser;

        WebDriver driver = DriverFactory.createDriver(resolvedBrowser);
        TL_DRIVER.set(driver);

        try {
            driver.manage().window().maximize();
        } catch (Exception ignored) {
            // Khong bat buoc maximize thanh cong, dac biet trong mot so moi truong headless.
        }

        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(configReader.getImplicitWait()));
        driver.get(configReader.getBaseUrl());
    }

    @AfterMethod(alwaysRun = true)
    public void tearDown(ITestResult result) {
        try {
            if (result.getStatus() == ITestResult.FAILURE && getDriver() != null) {
                ScreenshotUtil.capture(getDriver(), getDisplayName(result));
            }
        } finally {
            if (getDriver() != null) {
                getDriver().quit();
                TL_DRIVER.remove();
            }
            testName.remove();
        }
    }
}
