package framework.base;

import framework.config.ConfigReader;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

/**
 * Tao WebDriver theo browser duoc truyen vao.
 */
public final class DriverFactory {

    private DriverFactory() {
    }

    public static WebDriver createDriver(String browser) {
        String resolvedBrowser = (browser == null || browser.isBlank())
                ? ConfigReader.getInstance().getBrowser()
                : browser;

        switch (resolvedBrowser.toLowerCase()) {
            case "chrome":
            case "chromium":
                WebDriverManager.chromedriver().setup();

                ChromeOptions options = new ChromeOptions();
                options.addArguments("--remote-allow-origins=*");
                options.addArguments("--no-sandbox");
                options.addArguments("--disable-dev-shm-usage");

                if (Boolean.parseBoolean(System.getProperty("headless", "false"))) {
                    options.addArguments("--headless=new");
                    options.addArguments("--window-size=1920,1080");
                }

                return new ChromeDriver(options);

            default:
                throw new IllegalArgumentException("Khong ho tro browser: " + resolvedBrowser);
        }
    }
}
