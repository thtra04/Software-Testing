package framework.base;

import framework.config.ConfigReader;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * Lop nen cho tat ca Page Object.
 * Cung cap cac thao tac chung voi explicit wait de tai su dung va tranh viet lap.
 */
public abstract class BasePage {

    protected final WebDriver driver;
    protected final WebDriverWait wait;

    protected BasePage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(
                driver,
                Duration.ofSeconds(ConfigReader.getInstance().getExplicitWait()));
        PageFactory.initElements(driver, this);
    }

    /**
     * Cho phan tu co the click duoc roi click.
     * Dung khi muon tranh loi ElementNotInteractableException hoac click qua som.
     *
     * @param element phan tu can click
     */
    protected void waitAndClick(WebElement element) {
        wait.until(ExpectedConditions.elementToBeClickable(element));
        scrollToElement(element);
        element.click();
    }

    /**
     * Cho phan tu hien thi, xoa du lieu cu roi nhap du lieu moi.
     * Dung cho input field de tranh noi chuoi du lieu tu lan nhap truoc.
     *
     * @param element o nhap lieu
     * @param text gia tri can nhap
     */
    protected void waitAndType(WebElement element, String text) {
        WebElement visibleElement = wait.until(ExpectedConditions.visibilityOf(element));
        scrollToElement(visibleElement);
        visibleElement.clear();
        if (text != null) {
            visibleElement.sendKeys(text);
        }
    }

    /**
     * Lay text cua phan tu sau khi cho no hien thi.
     * Text duoc trim de tranh anh huong boi khoang trang dau cuoi.
     *
     * @param element phan tu can doc text
     * @return text da duoc trim
     */
    protected String getText(WebElement element) {
        return wait.until(ExpectedConditions.visibilityOf(element)).getText().trim();
    }

    /**
     * Kiem tra phan tu co dang hien thi hay khong.
     * Khong nem exception neu khong tim thay, stale hoac bi timeout.
     *
     * @param locator locator cua phan tu can kiem tra
     * @return true neu phan tu hien thi, false neu nguoc lai
     */
    protected boolean isElementVisible(By locator) {
        try {
            return wait.until(ExpectedConditions.visibilityOfElementLocated(locator)).isDisplayed();
        } catch (NoSuchElementException | StaleElementReferenceException | TimeoutException exception) {
            return false;
        }
    }

    /**
     * Cuon trang den vi tri cua phan tu.
     * Huu ich khi phan tu nam ngoai viewport.
     *
     * @param element phan tu can dua vao viewport
     */
    protected void scrollToElement(WebElement element) {
        wait.until(ExpectedConditions.visibilityOf(element));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block: 'center'});", element);
    }

    /**
     * Cho den khi tai lieu HTML load xong hoan toan.
     * Nen dung sau cac hanh dong dieu huong hoac reload trang.
     */
    protected void waitForPageLoad() {
        wait.until(webDriver ->
                "complete".equals(((JavascriptExecutor) webDriver)
                        .executeScript("return document.readyState")));
    }

    /**
     * Lay gia tri attribute sau khi phan tu hien thi.
     * Dung de doc gia tri hien tai cua input, class, href, data-* ...
     *
     * @param element phan tu can doc attribute
     * @param attributeName ten attribute can lay
     * @return gia tri attribute, co the null neu khong ton tai
     */
    protected String getAttribute(WebElement element, String attributeName) {
        return wait.until(ExpectedConditions.visibilityOf(element)).getAttribute(attributeName);
    }
}
