package framework.config;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Doc cau hinh theo moi truong duoc truyen bang System.getProperty("env").
 */
public final class ConfigReader {

    private static ConfigReader instance;
    private static String loadedEnv;
    private final Properties properties = new Properties();

    private ConfigReader(String env) {
        String fileName = "config-" + env + ".properties";

        try (InputStream inputStream = Thread.currentThread()
                .getContextClassLoader()
                .getResourceAsStream(fileName)) {

            if (inputStream == null) {
                throw new IllegalStateException("Khong tim thay file cau hinh: " + fileName);
            }

            properties.load(inputStream);
            System.out.println("[ConfigReader] Dang dung moi truong: " + env);
        } catch (IOException exception) {
            throw new RuntimeException("Khong the doc file cau hinh.", exception);
        }
    }

    public static synchronized ConfigReader getInstance() {
        String env = System.getProperty("env", "dev");

        if (instance == null || loadedEnv == null || !loadedEnv.equals(env)) {
            instance = new ConfigReader(env);
            loadedEnv = env;
        }

        return instance;
    }

    public static synchronized void reset() {
        instance = null;
        loadedEnv = null;
    }

    public String getBaseUrl() {
        return properties.getProperty("base.url");
    }

    public String getBrowser() {
        return properties.getProperty("browser", "chrome");
    }

    public int getExplicitWait() {
        return Integer.parseInt(properties.getProperty("explicit.wait", "15"));
    }

    public int getImplicitWait() {
        return Integer.parseInt(properties.getProperty("implicit.wait", "5"));
    }

    public String getScreenshotPath() {
        return properties.getProperty("screenshot.path", "target/screenshots");
    }

    public int getRetryCount() {
        return Integer.parseInt(properties.getProperty("retry.count", "2"));
    }
}
