package framework.utils;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 * Doc du lieu test tu file Excel va tra ve Object[][] de dung voi TestNG DataProvider.
 */
public final class ExcelReader {

    private ExcelReader() {
    }

    public static Object[][] getData(String resourcePath, String sheetName) {
        try (InputStream inputStream = resolveInputStream(resourcePath);
             Workbook workbook = new XSSFWorkbook(inputStream)) {

            Sheet sheet = workbook.getSheet(sheetName);
            if (sheet == null) {
                throw new RuntimeException("Khong tim thay sheet: " + sheetName);
            }

            Row headerRow = sheet.getRow(0);
            if (headerRow == null) {
                return new Object[0][0];
            }

            int lastRow = sheet.getLastRowNum();
            int lastColumn = headerRow.getLastCellNum();
            FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();

            List<Object[]> rows = new ArrayList<>();
            for (int rowIndex = 1; rowIndex <= lastRow; rowIndex++) {
                Row row = sheet.getRow(rowIndex);
                if (row == null || isRowEmpty(row, lastColumn, evaluator)) {
                    continue;
                }

                Object[] rowData = new Object[lastColumn];
                for (int columnIndex = 0; columnIndex < lastColumn; columnIndex++) {
                    Cell cell = row.getCell(columnIndex, Row.MissingCellPolicy.RETURN_BLANK_AS_NULL);
                    rowData[columnIndex] = getCellValue(cell, evaluator);
                }
                rows.add(rowData);
            }

            return rows.toArray(new Object[0][]);
        } catch (IOException exception) {
            throw new RuntimeException("Khong the doc file Excel: " + resourcePath, exception);
        }
    }

    public static String getCellValue(Cell cell) {
        if (cell == null) {
            return "";
        }
        FormulaEvaluator evaluator = cell.getSheet()
                .getWorkbook()
                .getCreationHelper()
                .createFormulaEvaluator();
        return getCellValue(cell, evaluator);
    }

    public static String getCellValue(Cell cell, FormulaEvaluator evaluator) {
        if (cell == null) {
            return "";
        }

        return switch (cell.getCellType()) {
            case STRING -> cell.getStringCellValue().trim();
            case NUMERIC -> normalizeNumericValue(cell.getNumericCellValue());
            case BOOLEAN -> String.valueOf(cell.getBooleanCellValue());
            case FORMULA -> getFormulaCellValue(cell, evaluator);
            default -> "";
        };
    }

    private static String getFormulaCellValue(Cell cell, FormulaEvaluator evaluator) {
        CellType formulaResultType = evaluator.evaluateFormulaCell(cell);

        return switch (formulaResultType) {
            case STRING -> cell.getStringCellValue().trim();
            case NUMERIC -> normalizeNumericValue(cell.getNumericCellValue());
            case BOOLEAN -> String.valueOf(cell.getBooleanCellValue());
            default -> "";
        };
    }

    private static String normalizeNumericValue(double numericValue) {
        if (numericValue == Math.floor(numericValue)) {
            return String.valueOf((long) numericValue);
        }
        return String.valueOf(numericValue);
    }

    private static boolean isRowEmpty(Row row, int lastColumn, FormulaEvaluator evaluator) {
        for (int columnIndex = 0; columnIndex < lastColumn; columnIndex++) {
            Cell cell = row.getCell(columnIndex, Row.MissingCellPolicy.RETURN_BLANK_AS_NULL);
            if (!getCellValue(cell, evaluator).isBlank()) {
                return false;
            }
        }
        return true;
    }

    private static InputStream resolveInputStream(String resourcePath) throws IOException {
        InputStream resourceStream = Thread.currentThread()
                .getContextClassLoader()
                .getResourceAsStream(resourcePath);

        if (resourceStream != null) {
            return resourceStream;
        }

        return new FileInputStream(resourcePath);
    }
}
