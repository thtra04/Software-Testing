package framework.utils;

import framework.config.ConfigReader;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

/**
 * Ho tro chup man hinh khi test fail.
 */
public final class ScreenshotUtil {

    private static final DateTimeFormatter FORMATTER =
            DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss_SSS");

    private ScreenshotUtil() {
    }

    public static String capture(WebDriver driver, String testName) {
        try {
            String screenshotFolder = ConfigReader.getInstance().getScreenshotPath();
            Path folderPath = Paths.get(screenshotFolder);
            Files.createDirectories(folderPath);

            String safeTestName = sanitizeFileName(testName);
            String fileName = safeTestName + "_" + LocalDateTime.now().format(FORMATTER) + ".png";
            Path targetPath = folderPath.resolve(fileName);

            File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            Files.copy(screenshot.toPath(), targetPath, StandardCopyOption.REPLACE_EXISTING);

            System.out.println("[Screenshot] Saved to: " + targetPath.toAbsolutePath());
            return targetPath.toString();
        } catch (IOException exception) {
            throw new RuntimeException("Khong the luu screenshot.", exception);
        }
    }

    private static String sanitizeFileName(String input) {
        if (input == null || input.isBlank()) {
            return "test";
        }
        return input.trim().replaceAll("[^a-zA-Z0-9-_]+", "_");
    }
}
