package framework.utils;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import framework.model.UserData;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

/**
 * Doc danh sach user tu file JSON.
 */
public final class JsonReader {

    private JsonReader() {
    }

    public static List<UserData> readUsers(String resourcePath) {
        ObjectMapper objectMapper = new ObjectMapper();

        try (InputStream inputStream = resolveInputStream(resourcePath)) {
            return objectMapper.readValue(inputStream, new TypeReference<List<UserData>>() { });
        } catch (IOException exception) {
            throw new RuntimeException("Khong the doc file JSON: " + resourcePath, exception);
        }
    }

    private static InputStream resolveInputStream(String resourcePath) throws IOException {
        InputStream resourceStream = Thread.currentThread()
                .getContextClassLoader()
                .getResourceAsStream(resourcePath);

        if (resourceStream != null) {
            return resourceStream;
        }

        return new FileInputStream(resourcePath);
    }
}
