package framework.utils;

import com.github.javafaker.Faker;
import framework.model.CheckoutData;
import java.util.Locale;

/**
 * Tap trung logic sinh test data ngau nhien.
 */
public final class TestDataFactory {

    private static final Faker FAKER = new Faker(new Locale("vi"));

    private TestDataFactory() {
    }

    public static String randomFirstName() {
        return FAKER.name().firstName();
    }

    public static String randomLastName() {
        return FAKER.name().lastName();
    }

    public static String randomPostalCode() {
        return FAKER.number().digits(5);
    }

    public static String randomEmail() {
        return FAKER.internet().emailAddress();
    }

    public static CheckoutData randomCheckoutData() {
        return new CheckoutData(
                randomFirstName(),
                randomLastName(),
                randomPostalCode());
    }
}
