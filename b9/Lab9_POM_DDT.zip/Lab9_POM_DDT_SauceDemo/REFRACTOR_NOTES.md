# Ghi chu bai 7 - Refactor tong hop

De bai yeu cau refactor code cu sang framework POM + DDT. Trong bo nop nay khong co source Lab 1/Lab 2 goc, vi vay phan refactor duoc the hien bang bo framework hoan chinh va tai lieu tom tat sau:

1. Toan bo locator duoc dua vao Page Object, test class khong goi `driver.findElement()` truc tiep.
2. Toan bo `Thread.sleep()` duoc loai bo, thay bang `WebDriverWait` trong `BasePage`.
3. Vong doi `WebDriver` duoc dua ve `BaseTest` voi `ThreadLocal<WebDriver>`.
4. Du lieu test dang nhap duoc tach ra `login_data.xlsx` va `users.json`.
5. URL, timeout, retry count duoc dua vao `config-dev.properties` va `config-staging.properties`.

Neu can tao git diff thuc te, chi can copy source cu vao nhanh khac roi so sanh voi cau truc hien tai.
