package framework.base;

import framework.config.ConfigReader;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public abstract class BasePage {

    protected final WebDriver driver;
    protected final WebDriverWait wait;

    protected BasePage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(ConfigReader.getInstance().getExplicitWait()));
        PageFactory.initElements(driver, this);
    }

    /**
     * Chờ phần tử có thể click rồi mới click để tránh lỗi phần tử chưa sẵn sàng.
     */
    protected void waitAndClick(WebElement element) {
        wait.until(ExpectedConditions.elementToBeClickable(element)).click();
    }

    /**
     * Chờ phần tử hiển thị, xóa dữ liệu cũ rồi nhập dữ liệu mới.
     */
    protected void waitAndType(WebElement element, String text) {
        WebElement visibleElement = wait.until(ExpectedConditions.visibilityOf(element));
        visibleElement.clear();
        visibleElement.sendKeys(text == null ? "" : text);
    }

    /**
     * Đọc text sau khi phần tử hiển thị và loại bỏ khoảng trắng đầu cuối.
     */
    protected String getText(WebElement element) {
        return wait.until(ExpectedConditions.visibilityOf(element)).getText().trim();
    }

    /**
     * Kiểm tra phần tử có hiển thị hay không, xử lý cả lỗi stale khi DOM bị render lại.
     */
    protected boolean isElementVisible(By locator) {
        try {
            return driver.findElement(locator).isDisplayed();
        } catch (NoSuchElementException | StaleElementReferenceException e) {
            return false;
        }
    }

    /**
     * Cuộn đến phần tử khi nó nằm ngoài viewport để thao tác ổn định hơn.
     */
    protected void scrollToElement(WebElement element) {
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block: 'center'});", element);
    }

    /**
     * Chờ tài liệu HTML load xong dựa trên document.readyState.
     */
    protected void waitForPageLoad() {
        wait.until(webDriver ->
            "complete".equals(((JavascriptExecutor) webDriver).executeScript("return document.readyState"))
        );
    }

    /**
     * Lấy giá trị attribute sau khi phần tử đã hiển thị.
     */
    protected String getAttribute(WebElement element, String attribute) {
        return wait.until(ExpectedConditions.visibilityOf(element)).getDomAttribute(attribute);
    }
}
