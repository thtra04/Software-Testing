package framework.config;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class ConfigReader {

    private static ConfigReader instance;
    private final Properties props = new Properties();
    private final String env;

    private ConfigReader() {
        env = System.getProperty("env", "dev");
        String filePath = "src/test/resources/config-" + env + ".properties";

        try (FileInputStream fileInputStream = new FileInputStream(filePath)) {
            props.load(fileInputStream);
            System.out.println("[ConfigReader] Dang dung moi truong: " + env);
        } catch (IOException e) {
            throw new RuntimeException("Khong tim thay config: " + filePath, e);
        }
    }

    public static synchronized ConfigReader getInstance() {
        String currentEnv = System.getProperty("env", "dev");
        if (instance == null || !instance.env.equals(currentEnv)) {
            instance = new ConfigReader();
        }
        return instance;
    }

    public static synchronized void reset() {
        instance = null;
    }

    public String getBaseUrl() {
        return props.getProperty("base.url");
    }

    public String getBrowser() {
        return props.getProperty("browser", "chrome");
    }

    public long getExplicitWait() {
        return Long.parseLong(props.getProperty("explicit.wait", "15"));
    }

    public long getImplicitWait() {
        return Long.parseLong(props.getProperty("implicit.wait", "5"));
    }

    public int getRetryCount() {
        return Integer.parseInt(props.getProperty("retry.count", "1"));
    }

    public String getScreenshotPath() {
        return props.getProperty("screenshot.path", "target/screenshots");
    }

    public String getProperty(String key) {
        return props.getProperty(key);
    }
}
