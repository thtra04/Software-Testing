package framework.pages;

import framework.base.BasePage;
import java.util.List;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CheckoutPage extends BasePage {

    @FindBy(id = "first-name")
    private WebElement firstNameField;

    @FindBy(id = "last-name")
    private WebElement lastNameField;

    @FindBy(id = "postal-code")
    private WebElement postalCodeField;

    @FindBy(id = "continue")
    private WebElement continueButton;

    @FindBy(id = "finish")
    private WebElement finishButton;

    @FindBy(css = ".complete-header")
    private List<WebElement> completeHeaders;

    public CheckoutPage(WebDriver driver) {
        super(driver);
    }

    public CheckoutPage fillCustomerInfo(String firstName, String lastName, String postalCode) {
        waitAndType(firstNameField, firstName);
        waitAndType(lastNameField, lastName);
        waitAndType(postalCodeField, postalCode);
        waitAndClick(continueButton);
        waitForPageLoad();
        return this;
    }

    public CheckoutPage finishCheckout() {
        waitAndClick(finishButton);
        waitForPageLoad();
        return this;
    }

    public boolean isComplete() {
        return completeHeaders != null && !completeHeaders.isEmpty() && completeHeaders.get(0).isDisplayed();
    }

    public String getCompletionMessage() {
        return completeHeaders == null || completeHeaders.isEmpty() ? "" : completeHeaders.get(0).getText().trim();
    }
}
