package framework.pages;

import framework.base.BasePage;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CartPage extends BasePage {

    @FindBy(css = ".cart_item")
    private List<WebElement> cartItems;

    @FindBy(css = ".cart_item button")
    private List<WebElement> removeButtons;

    @FindBy(id = "checkout")
    private WebElement checkoutButton;

    public CartPage(WebDriver driver) {
        super(driver);
    }

    public int getItemCount() {
        return cartItems == null ? 0 : cartItems.size();
    }

    public CartPage removeFirstItem() {
        if (removeButtons == null || removeButtons.isEmpty()) {
            return this;
        }
        waitAndClick(removeButtons.get(0));
        return this;
    }

    public CheckoutPage goToCheckout() {
        waitAndClick(checkoutButton);
        waitForPageLoad();
        return new CheckoutPage(driver);
    }

    public List<String> getItemNames() {
        if (cartItems == null || cartItems.isEmpty()) {
            return Collections.emptyList();
        }
        return cartItems.stream()
            .map(item -> item.findElement(By.cssSelector(".inventory_item_name")).getText().trim())
            .collect(Collectors.toList());
    }
}
