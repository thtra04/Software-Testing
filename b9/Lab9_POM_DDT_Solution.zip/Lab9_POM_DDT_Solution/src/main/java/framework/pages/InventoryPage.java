package framework.pages;

import framework.base.BasePage;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class InventoryPage extends BasePage {

    @FindBy(css = ".inventory_list")
    private WebElement inventoryList;

    @FindBy(css = ".shopping_cart_link")
    private WebElement cartLink;

    @FindBy(css = ".shopping_cart_badge")
    private List<WebElement> cartBadge;

    @FindBy(css = ".inventory_item button")
    private List<WebElement> addToCartButtons;

    @FindBy(css = ".inventory_item")
    private List<WebElement> inventoryItems;

    public InventoryPage(WebDriver driver) {
        super(driver);
    }

    public boolean isLoaded() {
        return inventoryList.isDisplayed();
    }

    public InventoryPage addFirstItemToCart() {
        if (addToCartButtons.isEmpty()) {
            throw new IllegalStateException("Khong co san pham nao de them vao gio");
        }
        waitAndClick(addToCartButtons.get(0));
        return this;
    }

    public InventoryPage addItemByName(String name) {
        for (WebElement inventoryItem : inventoryItems) {
            String itemName = inventoryItem.findElement(By.cssSelector(".inventory_item_name")).getText().trim();
            if (itemName.equalsIgnoreCase(name == null ? "" : name.trim())) {
                WebElement actionButton = inventoryItem.findElement(By.tagName("button"));
                scrollToElement(actionButton);
                waitAndClick(actionButton);
                return this;
            }
        }
        throw new NoSuchElementException("Khong tim thay san pham: " + name);
    }

    public int getCartItemCount() {
        if (cartBadge == null || cartBadge.isEmpty()) {
            return 0;
        }
        try {
            return Integer.parseInt(cartBadge.get(0).getText().trim());
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    public CartPage goToCart() {
        waitAndClick(cartLink);
        waitForPageLoad();
        return new CartPage(driver);
    }
}
