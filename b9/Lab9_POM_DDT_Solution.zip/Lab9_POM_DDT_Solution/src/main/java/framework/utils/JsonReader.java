package framework.utils;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import framework.model.UserData;
import java.io.File;
import java.io.IOException;
import java.util.List;

public final class JsonReader {

    private JsonReader() {
    }

    public static List<UserData> readUsers(String filePath) throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        return objectMapper.readValue(new File(filePath), new TypeReference<List<UserData>>() {});
    }
}
