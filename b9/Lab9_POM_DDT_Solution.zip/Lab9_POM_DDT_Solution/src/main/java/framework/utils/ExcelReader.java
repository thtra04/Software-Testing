package framework.utils;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public final class ExcelReader {

    private static final DataFormatter FORMATTER = new DataFormatter();

    private ExcelReader() {
    }

    public static Object[][] getData(String filePath, String sheetName) {
        try (FileInputStream fileInputStream = new FileInputStream(filePath);
             Workbook workbook = new XSSFWorkbook(fileInputStream)) {

            Sheet sheet = workbook.getSheet(sheetName);
            if (sheet == null) {
                throw new RuntimeException("Khong tim thay sheet: " + sheetName);
            }

            int lastColumn = sheet.getRow(0).getLastCellNum();
            List<Object[]> rows = new ArrayList<>();

            for (int rowIndex = 1; rowIndex <= sheet.getLastRowNum(); rowIndex++) {
                Row row = sheet.getRow(rowIndex);
                if (row == null || isEmptyRow(row, lastColumn)) {
                    continue;
                }

                Object[] data = new Object[lastColumn];
                for (int colIndex = 0; colIndex < lastColumn; colIndex++) {
                    data[colIndex] = getCellValue(row.getCell(colIndex));
                }
                rows.add(data);
            }

            return rows.toArray(new Object[0][]);
        } catch (IOException e) {
            throw new RuntimeException("Loi doc Excel: " + filePath, e);
        }
    }

    public static List<Map<String, String>> readSheetAsMaps(String filePath, String sheetName) {
        try (FileInputStream fileInputStream = new FileInputStream(filePath);
             Workbook workbook = new XSSFWorkbook(fileInputStream)) {

            Sheet sheet = workbook.getSheet(sheetName);
            if (sheet == null) {
                throw new RuntimeException("Khong tim thay sheet: " + sheetName);
            }

            Row headerRow = sheet.getRow(0);
            int lastColumn = headerRow.getLastCellNum();
            List<String> headers = new ArrayList<>();
            for (int colIndex = 0; colIndex < lastColumn; colIndex++) {
                headers.add(getCellValue(headerRow.getCell(colIndex)));
            }

            List<Map<String, String>> result = new ArrayList<>();
            for (int rowIndex = 1; rowIndex <= sheet.getLastRowNum(); rowIndex++) {
                Row row = sheet.getRow(rowIndex);
                if (row == null || isEmptyRow(row, lastColumn)) {
                    continue;
                }

                Map<String, String> data = new LinkedHashMap<>();
                for (int colIndex = 0; colIndex < lastColumn; colIndex++) {
                    data.put(headers.get(colIndex), getCellValue(row.getCell(colIndex)));
                }
                result.add(data);
            }

            return result;
        } catch (IOException e) {
            throw new RuntimeException("Loi doc Excel: " + filePath, e);
        }
    }

    public static String getCellValue(Cell cell) {
        if (cell == null) {
            return "";
        }

        CellType cellType = cell.getCellType();
        switch (cellType) {
            case STRING:
                return cell.getStringCellValue().trim();
            case NUMERIC:
                if (DateUtil.isCellDateFormatted(cell)) {
                    return cell.getLocalDateTimeCellValue().toString();
                }
                return FORMATTER.formatCellValue(cell).trim();
            case BOOLEAN:
                return String.valueOf(cell.getBooleanCellValue());
            case FORMULA:
                CellType cachedType = cell.getCachedFormulaResultType();
                switch (cachedType) {
                    case STRING:
                        return cell.getStringCellValue().trim();
                    case NUMERIC:
                        return FORMATTER.formatCellValue(cell).trim();
                    case BOOLEAN:
                        return String.valueOf(cell.getBooleanCellValue());
                    default:
                        return "";
                }
            default:
                return "";
        }
    }

    private static boolean isEmptyRow(Row row, int lastColumn) {
        for (int colIndex = 0; colIndex < lastColumn; colIndex++) {
            if (!getCellValue(row.getCell(colIndex)).isBlank()) {
                return false;
            }
        }
        return true;
    }
}
