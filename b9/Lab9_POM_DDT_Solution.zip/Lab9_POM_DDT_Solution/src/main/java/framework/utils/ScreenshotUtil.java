package framework.utils;

import framework.config.ConfigReader;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public final class ScreenshotUtil {

    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss");

    private ScreenshotUtil() {
    }

    public static String capture(WebDriver driver, String testName) {
        String directory = ConfigReader.getInstance().getScreenshotPath();
        try {
            Files.createDirectories(Paths.get(directory));
            String fileName = sanitize(testName) + "_" + LocalDateTime.now().format(FORMATTER) + ".png";
            File source = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            Path target = Paths.get(directory, fileName);
            Files.copy(source.toPath(), target, StandardCopyOption.REPLACE_EXISTING);
            return target.toString();
        } catch (IOException e) {
            throw new RuntimeException("Khong the chup screenshot cho test: " + testName, e);
        }
    }

    public static byte[] captureAsBytes(WebDriver driver) {
        return ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
    }

    private static String sanitize(String value) {
        return value == null ? "unknown_test" : value.replaceAll("[^a-zA-Z0-9._-]", "_");
    }
}
