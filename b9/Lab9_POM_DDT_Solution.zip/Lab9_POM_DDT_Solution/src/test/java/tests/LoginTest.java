package tests;

import framework.base.BaseTest;
import framework.config.ConfigReader;
import framework.pages.InventoryPage;
import framework.pages.LoginPage;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class LoginTest extends BaseTest {

    private ConfigReader config;

    @BeforeMethod(alwaysRun = true)
    public void loadConfig() {
        config = ConfigReader.getInstance();
    }

    @Test(groups = {"smoke", "regression"}, description = "Dang nhap hop le voi tai khoan mac dinh")
    public void shouldLoginSuccessfullyWithConfiguredCredentials() {
        InventoryPage inventoryPage = new LoginPage(getDriver())
            .login(config.getProperty("username"), config.getProperty("password"));

        Assert.assertTrue(inventoryPage.isLoaded(), "Inventory page phai hien thi sau khi login thanh cong");
    }

    @Test(groups = "regression", description = "Khong cho phep tai khoan bi khoa dang nhap")
    public void shouldShowErrorForLockedUser() {
        LoginPage loginPage = new LoginPage(getDriver())
            .loginExpectingFailure(config.getProperty("locked.user"), config.getProperty("password"));

        Assert.assertTrue(loginPage.isErrorDisplayed(), "Thong bao loi phai duoc hien thi");
        Assert.assertTrue(loginPage.getErrorMessage().contains("locked out"),
            "Thong bao phai noi ro user da bi khoa");
    }

    @Test(groups = "regression", description = "Bao loi khi bo trong username")
    public void shouldShowErrorForBlankUsername() {
        LoginPage loginPage = new LoginPage(getDriver())
            .loginExpectingFailure("", config.getProperty("password"));

        Assert.assertTrue(loginPage.isErrorDisplayed(), "Thong bao loi phai duoc hien thi");
        Assert.assertTrue(loginPage.getErrorMessage().contains("Username is required"));
    }

    @Test(groups = "regression", description = "Bao loi khi bo trong password")
    public void shouldShowErrorForBlankPassword() {
        LoginPage loginPage = new LoginPage(getDriver())
            .loginExpectingFailure(config.getProperty("username"), "");

        Assert.assertTrue(loginPage.isErrorDisplayed(), "Thong bao loi phai duoc hien thi");
        Assert.assertTrue(loginPage.getErrorMessage().contains("Password is required"));
    }
}
