package tests;

import framework.base.BaseTest;
import framework.config.ConfigReader;
import framework.pages.CheckoutPage;
import framework.pages.LoginPage;
import framework.utils.TestDataFactory;
import java.util.Map;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class CheckoutTest extends BaseTest {

    private ConfigReader config;

    @BeforeMethod(alwaysRun = true)
    public void loadConfig() {
        config = ConfigReader.getInstance();
    }

    @Test(groups = "regression", description = "Checkout thanh cong voi du lieu sinh ngau nhien bang Faker")
    public void shouldCompleteCheckoutWithFakerData() {
        Map<String, String> checkoutData = TestDataFactory.randomCheckoutData();

        CheckoutPage checkoutPage = new LoginPage(getDriver())
            .login(config.getProperty("username"), config.getProperty("password"))
            .addFirstItemToCart()
            .goToCart()
            .goToCheckout()
            .fillCustomerInfo(
                checkoutData.get("firstName"),
                checkoutData.get("lastName"),
                checkoutData.get("postalCode")
            )
            .finishCheckout();

        Assert.assertTrue(checkoutPage.isComplete(), "Checkout phai hoan tat thanh cong");
        Assert.assertTrue(checkoutPage.getCompletionMessage().contains("Thank you"));
    }
}
