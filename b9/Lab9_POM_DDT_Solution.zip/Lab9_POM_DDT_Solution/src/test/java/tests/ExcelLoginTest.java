package tests;

import framework.base.BaseTest;
import framework.pages.InventoryPage;
import framework.pages.LoginPage;
import framework.utils.ExcelReader;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.testng.Assert;
import org.testng.ITest;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class ExcelLoginTest extends BaseTest implements ITest {

    private static final String FILE_PATH = Paths.get(
        "src", "test", "resources", "testdata", "login_data.xlsx"
    ).toString();

    private final ThreadLocal<String> testName = new ThreadLocal<>();

    @Override
    public String getTestName() {
        return testName.get();
    }

    @BeforeMethod(alwaysRun = true)
    public void bindTestName(Object[] data) {
        if (data != null && data.length > 1) {
            testName.set(String.valueOf(data[1]));
        }
    }

    @AfterMethod(alwaysRun = true)
    public void clearTestName() {
        testName.remove();
    }

    @DataProvider(name = "smokeLoginData", parallel = true)
    public Object[][] smokeLoginData() {
        return toDataProvider(ExcelReader.readSheetAsMaps(FILE_PATH, "SmokeCases"));
    }

    @DataProvider(name = "regressionLoginData", parallel = true)
    public Object[][] regressionLoginData() {
        List<Map<String, String>> data = new ArrayList<>();
        data.addAll(ExcelReader.readSheetAsMaps(FILE_PATH, "SmokeCases"));
        data.addAll(ExcelReader.readSheetAsMaps(FILE_PATH, "NegativeCases"));
        data.addAll(ExcelReader.readSheetAsMaps(FILE_PATH, "BoundaryCases"));
        return toDataProvider(data);
    }

    @Test(groups = "smoke", dataProvider = "smokeLoginData")
    public void loginFromSmokeSheet(Map<String, String> row, String description) {
        executeRow(row);
    }

    @Test(groups = "regression", dataProvider = "regressionLoginData")
    public void loginFromAllSheets(Map<String, String> row, String description) {
        executeRow(row);
    }

    private Object[][] toDataProvider(List<Map<String, String>> rows) {
        return rows.stream()
            .map(row -> new Object[]{row, row.getOrDefault("description", "Excel case")})
            .toArray(Object[][]::new);
    }

    private void executeRow(Map<String, String> row) {
        String username = row.getOrDefault("username", "");
        String password = row.getOrDefault("password", "");

        if (row.containsKey("expected_url")) {
            InventoryPage inventoryPage = new LoginPage(getDriver()).login(username, password);
            Assert.assertTrue(inventoryPage.isLoaded(), "Dang nhap thanh cong thi inventory phai load");
            Assert.assertTrue(
                getDriver().getCurrentUrl().contains(row.get("expected_url")),
                "Current URL phai chua duong dan mong doi"
            );
            return;
        }

        LoginPage loginPage = new LoginPage(getDriver()).loginExpectingFailure(username, password);
        Assert.assertTrue(loginPage.isErrorDisplayed(), "Case fail phai hien thi error");
        Assert.assertTrue(
            loginPage.getErrorMessage().contains(row.getOrDefault("expected_error", "")),
            "Noi dung loi khong khop voi du lieu Excel"
        );
    }
}
