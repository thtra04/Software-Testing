package tests;

import framework.base.BaseTest;
import framework.config.ConfigReader;
import framework.pages.CartPage;
import framework.pages.InventoryPage;
import framework.pages.LoginPage;
import java.util.List;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class CartTest extends BaseTest {

    private ConfigReader config;

    @BeforeMethod(alwaysRun = true)
    public void loadConfig() {
        config = ConfigReader.getInstance();
    }

    @Test(groups = {"smoke", "regression"}, description = "Them san pham dau tien vao gio hang")
    public void shouldAddFirstItemAndIncreaseCartBadge() {
        InventoryPage inventoryPage = new LoginPage(getDriver())
            .login(config.getProperty("username"), config.getProperty("password"))
            .addFirstItemToCart();

        Assert.assertEquals(inventoryPage.getCartItemCount(), 1, "Badge gio hang phai tang len 1");
    }

    @Test(groups = "regression", description = "Item da chon phai xuat hien trong gio hang")
    public void shouldOpenCartWithSelectedItem() {
        CartPage cartPage = new LoginPage(getDriver())
            .login(config.getProperty("username"), config.getProperty("password"))
            .addFirstItemToCart()
            .goToCart();

        List<String> itemNames = cartPage.getItemNames();
        Assert.assertEquals(cartPage.getItemCount(), 1, "Phai co 1 item trong gio");
        Assert.assertFalse(itemNames.isEmpty(), "Danh sach item trong gio hang khong duoc rong");
    }

    @Test(groups = "regression", description = "Xoa item dau tien khoi gio hang")
    public void shouldRemoveFirstItemFromCart() {
        CartPage cartPage = new LoginPage(getDriver())
            .login(config.getProperty("username"), config.getProperty("password"))
            .addFirstItemToCart()
            .goToCart()
            .removeFirstItem();

        Assert.assertEquals(cartPage.getItemCount(), 0, "Sau khi xoa thi gio hang phai rong");
    }
}
