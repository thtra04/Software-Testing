package tests;

import framework.base.BaseTest;
import framework.model.UserData;
import framework.pages.InventoryPage;
import framework.pages.LoginPage;
import framework.utils.JsonReader;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.List;
import org.testng.Assert;
import org.testng.ITest;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class UserLoginTest extends BaseTest implements ITest {

    private static final String FILE_PATH = Paths.get(
        "src", "test", "resources", "testdata", "users.json"
    ).toString();

    private final ThreadLocal<String> testName = new ThreadLocal<>();

    @Override
    public String getTestName() {
        return testName.get();
    }

    @BeforeMethod(alwaysRun = true)
    public void bindTestName(Object[] data) {
        if (data != null && data.length > 1) {
            testName.set(String.valueOf(data[1]));
        }
    }

    @AfterMethod(alwaysRun = true)
    public void clearName() {
        testName.remove();
    }

    @DataProvider(name = "jsonUsers")
    public Object[][] jsonUsers() throws IOException {
        List<UserData> users = JsonReader.readUsers(FILE_PATH);
        return users.stream()
            .map(user -> new Object[]{user, user.getDescription()})
            .toArray(Object[][]::new);
    }

    @Test(groups = "regression", dataProvider = "jsonUsers")
    public void loginFromJson(UserData user, String description) {
        if (user.isExpectSuccess()) {
            InventoryPage inventoryPage = new LoginPage(getDriver())
                .login(user.getUsername(), user.getPassword());
            Assert.assertTrue(inventoryPage.isLoaded(), "Case JSON success phai vao duoc inventory");
            return;
        }

        LoginPage loginPage = new LoginPage(getDriver())
            .loginExpectingFailure(user.getUsername(), user.getPassword());

        Assert.assertTrue(loginPage.isErrorDisplayed(), "Case JSON fail phai hien thi error");
    }
}
