# Lab 9 - Page Object Model nang cao + Data-Driven Testing

Day la bo source hoan chinh cho bai lab 9 voi cac thanh phan chinh:

- BasePage va BaseTest dung lai cho toan framework
- Page Object cho LoginPage, InventoryPage, CartPage va CheckoutPage
- Data-driven testing bang Excel va JSON
- ConfigReader doc cau hinh theo moi truong dev / staging
- RetryAnalyzer + RetryListener de retry test flaky
- TestDataFactory dung Java Faker cho du lieu checkout
- testng-smoke.xml va testng-regression.xml

## Cau truc nhanh
- `src/main/java/framework/base`: lop nen
- `src/main/java/framework/pages`: page object
- `src/main/java/framework/utils`: reader, screenshot, retry, faker
- `src/test/java/tests`: cac lop test
- `src/test/resources/testdata`: file Excel va JSON

## Cach chay
```bash
mvn test -Denv=dev
mvn test -Denv=staging
mvn test -Dsurefire.suiteXmlFiles=src/test/resources/testng-smoke.xml -Denv=dev
mvn test -Dsurefire.suiteXmlFiles=src/test/resources/testng-regression.xml -Denv=staging
```

## Ghi chu
- `config-staging.properties` dung URL co query `?env=staging` de phan biet moi truong, trong du an that co the thay bang domain staging rieng.
- Screenshot loi se duoc luu vao `target/screenshots`.
- Do moi truong tao file khong co trinh duyet va dependency cache day du, source chua duoc chay thuc te trong container nay. Khi mo bang IDE, hay chay Maven de sinh TestNG report va screenshot that.
